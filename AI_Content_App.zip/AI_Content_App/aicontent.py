import os
import openai
import config
openai.api_key = config.OPENAI_API_KEY


def essayOutline(query):
    response = openai.Completion.create(
      model="text-davinci-002",
      prompt="Create an outline for an essay about {}:".format(query),
      temperature=0.7,
      max_tokens=550,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0)
              
    if 'choices' in response:
    	if len(response['choices']) > 0:
    		answer = response['choices'][0]['text']
    	else:
    		answer = 'Sorry, I could not help you this time'
    		
    		
    return answer

def productDescription(query):
    response = openai.Completion.create(
      model="text-davinci-002",
      prompt="Generate a detailed product description with a professional tone for: {}".format(query),
      temperature=0.7,
      max_tokens=750,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0)
              
    if 'choices' in response:
    	if len(response['choices']) > 0:
    		answer = response['choices'][0]['text']
    	else:
    		answer = 'Sorry, I could not help you this time'
    		
    		
    return answer		
    #print(answer)

#query = 'BlackVue camera'
#productDescription(query)


def jobDescription(query):
    response = openai.Completion.create(
      model="text-davinci-002",
      prompt="What is the job description of a: {}".format(query),
      temperature=0.7,
      max_tokens=500,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0)
              
    if 'choices' in response:
    	if len(response['choices']) > 0:
    		answer = response['choices'][0]['text']
    	else:
    		answer = 'Sorry, I could not help you this time'
    		
    		
    return answer


def tweetIdeas(query):
    response = openai.Completion.create(
      model="text-davinci-002",
      prompt="Write a tweet about: {}".format(query),
      temperature=0.7,
      max_tokens=200,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0)
              
    if 'choices' in response:
    	if len(response['choices']) > 0:
    		answer = response['choices'][0]['text']
    	else:
    		answer = 'Sorry, I could not help you this time'
    		
    		
    return answer


def coldEmails(query):
    response = openai.Completion.create(
      model="text-davinci-002",
      prompt="Write an engaging cold email about: {}".format(query),
      temperature=0.7,
      max_tokens=750,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0)
              
    if 'choices' in response:
    	if len(response['choices']) > 0:
    		answer = response['choices'][0]['text']
    	else:
    		answer = 'Sorry, I could not help you this time'
    		
    		
    return answer		
    


def socialMedia(query):
    response = openai.Completion.create(
      model="text-davinci-002",
      prompt="Write a social media advert for: {}".format(query),
      temperature=0.7,
      max_tokens=750,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0)
              
    if 'choices' in response:
    	if len(response['choices']) > 0:
    		answer = response['choices'][0]['text']
    	else:
    		answer = 'Sorry, I could not help you this time'
    		
    		
    return answer


def businessPitch(query):
    response = openai.Completion.create(
      model="text-davinci-002",
      prompt="Write a business pitch with a professional tone for: {}".format(query),
      temperature=0.7,
      max_tokens=750,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0)
              
    if 'choices' in response:
    	if len(response['choices']) > 0:
    		answer = response['choices'][0]['text']
    	else:
    		answer = 'Sorry, I could not help you this time'
    		
    		
    return answer		
 

def videoIdeas(query):
    response = openai.Completion.create(
      model="text-davinci-002",
      prompt="Generate video ideas for: {}".format(query),
      temperature=0.7,
      max_tokens=750,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0)
              
    if 'choices' in response:
    	if len(response['choices']) > 0:
    		answer = response['choices'][0]['text']
    	else:
    		answer = 'Sorry, I could not help you this time'
    		
    		
    return answer		



def videoDescription(query):
    response = openai.Completion.create(
      model="text-davinci-002",
      prompt="Generate a detailed video description for: {}".format(query),
      temperature=0.7,
      max_tokens=750,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0)
              
    if 'choices' in response:
    	if len(response['choices']) > 0:
    		answer = response['choices'][0]['text']
    	else:
    		answer = 'Sorry, I could not help you this time'
    		
    		
    return answer		
	

