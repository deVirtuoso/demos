# ai-content-starting-template
This is the starting template for a content generator website that uses AI in the background to generate the content. 
