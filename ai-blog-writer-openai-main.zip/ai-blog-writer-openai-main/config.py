##OPEN API STUFF
OPENAI_API_KEY = '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'



## FLASK STUFF
class Config(object):
    DEBUG = True
    TESTING = False

class DevelopmentConfig(Config):
    SECRET_KEY = "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"


config = {
    'development': DevelopmentConfig,
    'testing': DevelopmentConfig,
    'production': DevelopmentConfig
}
