# invoicing

This repo contains files from Skolo Online youtbe channel - teaching how to create an invoicing app from scratch using python, django and bootsrap.
This is the first lesson in the series.

## Youtube Channel
watch how to use this repo on youtube step by step.
[Creating a django invoicing app step by step](https://www.youtube.com/watch?v=9XE0sf0XYuw)

## Medium channel
Read about installing a django app from scratch step by step.
[How to create a django app from scratch](https://skolo-online.medium.com/getting-started-with-python-django-web-development-4e073e64c4a0)
